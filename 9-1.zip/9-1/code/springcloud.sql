/*
SQLyog Ultimate v12.5.0 (64 bit)
MySQL - 5.7.28-log : Database - springcloud
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`springcloud` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `springcloud`;

/*Table structure for table `orders` */

DROP TABLE IF EXISTS `orders`;

CREATE TABLE `orders` (
  `oid` int(11) NOT NULL AUTO_INCREMENT COMMENT '订单号',
  `created_time` varchar(55) NOT NULL COMMENT '订单创建时间',
  `statu` varchar(10) NOT NULL COMMENT '订单状态(未支付，已支付，已失效，已删除)',
  `pid` int(11) DEFAULT NULL COMMENT '商品id',
  PRIMARY KEY (`oid`),
  KEY `pid` (`pid`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`pid`) REFERENCES `product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

/*Data for the table `orders` */

insert  into `orders`(`oid`,`created_time`,`statu`,`pid`) values 
(1,'2020-12-31 13:44','已删除',1),
(2,'2020-12-31 13:44','已删除',1),
(3,'2020-12-21 13:44','已失效',1),
(4,'2020-12-31 15:44','已支付',1),
(5,'2020-12-31 16:44','已支付',2),
(6,'2020-12-31 12:44','已失效',2),
(7,'2020-11-11 13:44','未支付',3),
(8,'2020-12-31 13:44','已支付',3),
(9,'2020-12-31 13:44','已失效',3),
(10,'2020-12-31 13:44','已失效',4),
(11,'2020-12-31 13:44','已失效',5),
(12,'2020-12-31 13:44','已删除',6),
(13,'2020-12-31 13:44','已支付',6),
(14,'2020-12-31 13:44','已支付',6),
(15,'2020-12-31 13:44','已支付',13),
(16,'2020-12-31 13:44','已删除',11),
(17,'2020-12-31 13:44','已删除',12);

/*Table structure for table `orders_list` */

DROP TABLE IF EXISTS `orders_list`;

CREATE TABLE `orders_list` (
  `list_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '记录序号',
  `oid` int(11) DEFAULT NULL COMMENT '订单ID',
  `product_id` int(11) DEFAULT NULL COMMENT '商品ID',
  PRIMARY KEY (`list_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

/*Data for the table `orders_list` */

insert  into `orders_list`(`list_id`,`oid`,`product_id`) values 
(1,1,1),
(2,1,2),
(3,1,3),
(4,2,1),
(5,2,2),
(6,2,8),
(7,3,7),
(8,4,5),
(9,4,6),
(10,5,1),
(11,5,2),
(12,5,3),
(13,5,4),
(14,5,8),
(15,5,9),
(16,6,1),
(17,6,9);

/*Table structure for table `product` */

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品ID',
  `name` varchar(55) NOT NULL COMMENT '商品名称',
  `type` varchar(30) NOT NULL COMMENT '商品分类',
  `price_range` double DEFAULT NULL COMMENT '商品价格范围',
  `storage_range` int(11) NOT NULL COMMENT '库存范围',
  `statu` varchar(5) NOT NULL COMMENT '上架状态',
  `orders_id` int(11) DEFAULT NULL COMMENT '订单信息',
  PRIMARY KEY (`id`),
  KEY `orders_id` (`orders_id`),
  CONSTRAINT `product_ibfk_1` FOREIGN KEY (`orders_id`) REFERENCES `orders` (`oid`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

/*Data for the table `product` */

insert  into `product`(`id`,`name`,`type`,`price_range`,`storage_range`,`statu`,`orders_id`) values 
(1,'棒棒糖','零食',2323.89,23,'已下架',1),
(2,'高达模型PG限定','模型',321.99,19,'已上架',2),
(3,'Java-从入门到劝退','书籍',1.99,1999,'已上架',3),
(4,'Mysql-从删库到跑路','书籍',1.99,1999,'已下架',3),
(5,'论程序员的修养','书籍',1.99,129,'已上架',3),
(6,'挪威森林','书籍',1.99,9123,'已上架',3),
(7,'猫屎咖啡','饮料',1.99,4123,'已下架',3),
(8,'脉动','饮料',1.99,4123,'已下架',4),
(9,'可口可乐','饮料',1.99,91423,'已上架',5),
(10,'康师傅冰红茶','饮料',1.99,223123,'已上架',6),
(11,'2666MHz内存条','电子产品',199,555,'已下架',6),
(12,'微星3090Ti','电子产品',13999,4,'已下架',7),
(13,'七彩虹2070ti','电子产品',2800.99,222,'已下架',8),
(14,'AMDRandon6800XT','电子产品',8999.99,12,'已上架',9);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
