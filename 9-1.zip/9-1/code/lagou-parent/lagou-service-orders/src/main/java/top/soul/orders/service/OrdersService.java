package top.soul.orders.service;

import top.soul.entity.Orders;
import top.soul.entity.OrdersVO;
import top.soul.entity.Product;

import java.util.List;
import java.util.Map;

public interface OrdersService {
    /**
     * 根据ID查询订单信息
     * @param oid 订单oid
     * */
    Orders findOrderById(Integer oid);

    /**
     * 分页查询
     * 订单创建时间范围、订单状态（未支付、已支付、已失效、已删除）
     * */
    Map<List,Integer> findProductsByOid(OrdersVO ordersVO);
}
