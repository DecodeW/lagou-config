package top.soul.orders.fegin;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import top.soul.entity.Product;
import top.soul.entity.ProductVO;
import top.soul.orders.fegin.fallback.ProductFeginFallBack;

import java.util.List;
import java.util.Map;

@FeignClient(name = "lagou-service-product",fallback = ProductFeginFallBack.class)
public interface ProductFegin {

    /**
     *  根据OID获取商品信息列表
     * */
    @GetMapping("/product/findAll/{oid}")
    public List<Product> findAllProductsByOid(@PathVariable Integer oid);
    /**
     * 通过id获取商品信息
     * @param id
     * @return
     * */
    @RequestMapping("/product/findProductById/{id}")
    public Product query(@PathVariable Integer id);

    /**
     * 根据ID删除商品信息
     * @param id
     * @return
     * */
    @GetMapping("/product/delProductById/{id}")
    public Integer del(@PathVariable Integer id);
    /**
     * 根据ID修改商品信息
     * */
    @PostMapping("/product/updateProductById")
    public Integer update(Product product);

    /**
     * 分页查询商品信息
     * */
    @PostMapping("/product/getDataByPage")
    public Map<List,Integer> getData(ProductVO productVO);
}
