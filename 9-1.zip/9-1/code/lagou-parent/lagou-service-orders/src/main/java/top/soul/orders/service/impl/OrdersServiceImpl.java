package top.soul.orders.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import top.soul.entity.Orders;
import top.soul.entity.OrdersVO;
import top.soul.entity.Product;
import top.soul.orders.mapper.OrdersMapper;
import top.soul.orders.service.OrdersService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Service
public class OrdersServiceImpl implements OrdersService {
    @Autowired
    private OrdersMapper ordersMapper;

    @Override
    public Orders findOrderById(Integer oid) {
        return ordersMapper.selectById(oid);
    }

    /**
     *订单创建时间范围、订单状态（未支付、已支付、已失效、已删除）
     * */
    @Override
    public Map<List, Integer> findProductsByOid(OrdersVO ordersVO) {
        //初始化page对象
        Page<Orders> page = new Page<>(ordersVO.getCurrentPage(),10);
        QueryWrapper<Orders> queryWrapper = new QueryWrapper<>();
        //订单创建时间
        if (ordersVO.getCreatedTime()!=null && !ordersVO.getCreatedTime().equals("")){
            queryWrapper.eq("created_time",ordersVO.getCreatedTime());
        }
        //订单状态
        if (ordersVO.getStatu()!=null && !ordersVO.getStatu().equals("")){
            queryWrapper.eq("statu",ordersVO.getStatu());
        }
        Page<Orders> ordersPage = ordersMapper.selectPage(page, queryWrapper);
        Integer total =(int)ordersPage.getTotal();
        List<Orders> ordersList = ordersPage.getRecords();
        Map<List,Integer> map=new HashMap<>();
        map.put(ordersList,total);
        return map;
    }
}
