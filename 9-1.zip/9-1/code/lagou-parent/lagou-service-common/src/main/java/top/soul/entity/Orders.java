package top.soul.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * (Orders)实体类
 *
 * @author Wangbin
 * @since 2021-01-08 21:27:36
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "orders")
public class Orders implements Serializable {
    private static final long serialVersionUID = 862856361041716457L;
    /**
     * 订单号
     */
    @TableId(value = "oid")
    private Integer oid;
    /**
     * 订单创建时间
     */
    private String createdTime;
    /**
     * 订单状态(未支付，已支付，已失效，已删除)
     */
    private String statu;
    /**
     * 商品id
     */
    private Integer pid;


}