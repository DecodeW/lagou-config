package top.soul.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.io.Serializable;

/**
 * (Product)实体类
 *
 * @author Wangbin
 * @since 2021-01-08 21:28:28
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Table(name = "product")
public class Product implements Serializable {
    private static final long serialVersionUID = 452830655158355797L;
    /**
     * 商品ID
     */
    @TableId(value = "id")
    private Integer id;
    /**
     * 商品名称
     */
    private String name;
    /**
     * 商品分类
     */
    private String type;
    /**
     * 商品价格范围
     */
    private Object priceRange;
    /**
     * 库存范围
     */
    private Integer storageRange;
    /**
     * 上架状态
     */
    private String statu;


}