package top.soul.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductVO implements Serializable {

    private static final long serialVersionUID = 8162740432398538771L;
    /**
     * 商品ID
     */
    private Integer id;
    /**
     * 商品名称
     */
    private String name;
    /**
     * 商品分类
     */
    private String type;
    /**
     * 商品价格范围
     */
    private Object priceRange;
    /**
     * 库存范围
     */
    private Integer storageRange;
    /**
     * 上架状态
     */
    private String statu;

    /**
     * 当前页数
     * */
    private Integer pageSize;
}
