package top.soul.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrdersVO implements Serializable {

    private static final long serialVersionUID = 2316766147029718424L;
    /**
     * 订单号
     */
    private Integer oid;
    /**
     * 订单创建时间
     */
    private String createdTime;
    /**
     * 订单状态(未支付，已支付，已失效，已删除)
     */
    private String statu;
    /**
     * 商品id
     */
    private Integer pid;

    /**
     * 分页查询当前页数
     * */
    private Integer currentPage;
}
