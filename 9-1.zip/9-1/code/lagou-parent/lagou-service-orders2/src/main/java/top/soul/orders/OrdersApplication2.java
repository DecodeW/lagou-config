package top.soul.orders;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients //开启Feign  会自动引入Hytsrix注解
@MapperScan("top.soul.orders.mapper")
public class OrdersApplication2 {
    public static void main(String[] args) {
        SpringApplication.run(OrdersApplication2.class,args);
    }
    @Bean
    @LoadBalanced  //开启Ribbon负载均衡
    public RestTemplate restTemplate(){
        return new RestTemplate();
    }
}
