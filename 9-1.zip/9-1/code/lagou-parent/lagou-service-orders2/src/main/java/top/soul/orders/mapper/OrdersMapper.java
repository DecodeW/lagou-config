package top.soul.orders.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import top.soul.entity.Orders;

public interface OrdersMapper extends BaseMapper<Orders> {
}
