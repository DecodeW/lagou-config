package top.soul.orders.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import top.soul.entity.Orders;
import top.soul.entity.OrdersVO;
import top.soul.entity.Product;
import top.soul.entity.ProductVO;
import top.soul.orders.fegin.ProductFegin;
import top.soul.orders.service.OrdersService;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/orders")
public class OrdersController2 {

    @Autowired
    private ProductFegin productFegin;
    @Autowired
    private OrdersService ordersService;

    @GetMapping("/findOrdersById/{oid}")
    public Orders query(@PathVariable Integer oid){
        return ordersService.findOrderById(oid);
    }

    @PostMapping("/findAllOrders")
    public Map<List,Integer> getData(OrdersVO ordersVO){
        return ordersService.findProductsByOid(ordersVO);
    }


    /*
        Fegin 远程调用商品微服务
    */
    @GetMapping("/findAllProducts/{oid}")
    public List<Product> findAllProductsByOid(@PathVariable Integer oid){
        return productFegin.findAllProductsByOid(oid);
    }
    @GetMapping("/findGoodsById/{oid}")
    public Product getData(@PathVariable Integer oid){
        return productFegin.query(oid);
    }
    /**
     * 根据ID删除商品信息
     * */
    @GetMapping("/delProductById/{id}")
    public Integer del(@PathVariable Integer id){
        return productFegin.del(id);
    }
    /**
     * 根据ID修改商品信息
     * */
    @PostMapping("/updateProductById")
    public Integer update(Product product){
        return productFegin.update(product);
    }

    /**
     * 分页查询商品信息
     * */
    @PostMapping("/getDataByPage")
    public Map<List,Integer> getData(ProductVO productVO){
        return productFegin.getData(productVO);
    }

}
