package top.soul.orders.fegin.fallback;

import org.springframework.stereotype.Component;
import top.soul.entity.Product;
import top.soul.entity.ProductVO;
import top.soul.orders.fegin.ProductFegin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class ProductFeginFallBack implements ProductFegin {
    @Override
    public Product query(Integer id) {
        return new Product();
    }
    @Override
    public Integer del(Integer id) {
        return -1;
    }

    @Override
    public Integer update(Product product) {
        return -1;
    }

    @Override
    public Map<List, Integer> getData(ProductVO productVO) {
        return new HashMap<List, Integer>();
    }

    @Override
    public List<Product> findAllProductsByOid(Integer oid) {
        return new ArrayList<Product>();
    }
}
