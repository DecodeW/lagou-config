package top.soul.orders.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/config")
public class ConfigController {
    @Value("${slogan.value}")
    private String slogan;

    @GetMapping("/getConfig")
    public String getConfig(){
        return "slogan:"+slogan;
    }
}
