package top.soul.product.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import top.soul.entity.Product;
import top.soul.entity.ProductVO;
import top.soul.product.service.ProductService;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/product")
public class ProductController {
    @Autowired
    private ProductService productService;

    @GetMapping("/findProductById/{id}")
    public Product query(@PathVariable Integer id){
        return productService.findProductById(id);
    }

    @GetMapping("/delProductById/{id}")
    public Integer del(@PathVariable Integer id){
        return productService.delProductById(id);
    }
    @PostMapping("/updateProductById")
    public Integer update(Product product){
        return productService.updateProductById(product);
    }

    @PostMapping("/getDataByPage")
    public Map<List,Integer> getData(ProductVO productVO){
        return productService.findAllProduct(productVO);
    }
    @GetMapping("/findAll/{oid}")
    public List<Product> findAllProductsByOid(@PathVariable Integer oid) {
        return productService.findAllProductsByOid(oid);
    }

}
