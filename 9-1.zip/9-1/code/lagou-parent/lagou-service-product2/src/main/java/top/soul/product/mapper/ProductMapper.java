package top.soul.product.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import top.soul.entity.Product;

public interface ProductMapper extends BaseMapper<Product> {

}
