package top.soul.product.service;


import top.soul.entity.Product;
import top.soul.entity.ProductVO;

import java.util.List;
import java.util.Map;

public interface ProductService {
    /**
     * 根据ID查询商品信息
     * @param id 商品id
     * */
    Product findProductById(Integer id);

    /**
     *  根据id删除商品
     * @param id 商品id
     * */
    Integer delProductById(Integer id);
    /**
     * 根据id编辑商品
     * */
    Integer updateProductById(Product product);

    /**
     * 根据订单ID查询商品信息
     * @param oid 订单id
     * */
    List<Product> findAllProductsByOid(Integer oid);
    /**
     * 分页查询
     * 商品名称、分类、价格范围、库存范围、上架状态
     * */
    Map<List,Integer> findAllProduct(ProductVO productVO);


}
