package top.soul.product.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import top.soul.entity.Product;
import top.soul.entity.ProductVO;
import top.soul.product.mapper.ProductMapper;
import top.soul.product.service.ProductService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductMapper productMapper;

    @Override
    public Product findProductById(Integer id) {
        return productMapper.selectById(id);
    }

    @Override
    public Integer delProductById(Integer id) {
        return productMapper.deleteById(id);
    }

    @Override
    public Integer updateProductById(Product product) {
        return productMapper.updateById(product);
    }

    @Override
    public List<Product> findAllProductsByOid(Integer oid) {
        QueryWrapper<Product> wrapper = new QueryWrapper<>();
        //根据订单id查询商品信息
        wrapper.eq("orders_id",oid);
        return productMapper.selectList(wrapper);
    }

    /**
     * pageSize = 10
     *
     * 查询条件：商品名称、分类、价格范围、库存范围、上架状态
     *
     * 返回类型：Map（list:商品集合、total:总条目数）
     * */
    @Override
    public Map<List,Integer> findAllProduct(ProductVO productVO){
        //每页显示数量为10
        Page<Product> page = new Page<>(productVO.getPageSize(), 10);
        QueryWrapper<Product> queryWrapper = new QueryWrapper<>();
        //商品名称判断
        if (productVO.getName()!=null && !productVO.getName().equals("")){
            queryWrapper.eq("name",productVO.getName());
        }
        //商品分类
        if (productVO.getType()!=null && !productVO.getType().equals("")){
            queryWrapper.eq("type",productVO.getType());
        }
        //商品价格
        if (productVO.getPriceRange()!=null){
            queryWrapper.ge("price_range",productVO.getPriceRange());
        }
        //库存
        if (productVO.getStorageRange()!=null && productVO.getStorageRange()>=0){
            queryWrapper.ge("storage_range",productVO.getStorageRange());
        }
        //上架状态
        if (productVO.getStatu()!=null && !productVO.getStatu().equals("")){
            queryWrapper.eq("statu",productVO.getStatu());
        }
        Page<Product> productPage = productMapper.selectPage(page, queryWrapper);
        List<Product> productList = productPage.getRecords();
        Integer total =(int)productPage.getTotal();
        Map<List, Integer> map = new HashMap<>();
        map.put(productList,total);
        return map;
    }
}
